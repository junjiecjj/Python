
# -*- coding: utf-8 -*-
"""
Created on 2023/04/25

@author: Junjie Chen

"""

import os, sys
import math
import datetime
import imageio
import cv2
import skimage
import glob
import random
import numpy as np
import torch

import matplotlib
# matplotlib.use('TkAgg')
matplotlib.use('Agg')


#### 本项目自己编写的库
# sys.path.append("..")


fontpath = "/usr/share/fonts/truetype/windows/"
fontpath1 = "/usr/share/fonts/truetype/msttcorefonts/"
fontpath2 = "/usr/share/fonts/truetype/NerdFonts/"



# 初始化随机数种子
def set_random_seed(seed = 10, deterministic = False, benchmark = False):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.deterministic = True
    if benchmark:
        torch.backends.cudnn.benchmark = True
    return

def set_printoption(precision = 3):
    np.set_printoptions(formatter={'float': '{: 0.3f}'.format})
    torch.set_printoptions(
        precision = precision,    # 精度，保留小数点后几位，默认4
        threshold = 1000,
        edgeitems = 3,
        linewidth = 150,  # 每行最多显示的字符数，默认80，超过则换行显示
        profile = None,
        sci_mode = False  # 用科学技术法显示数据，默认True
        )


## 功能：
class checkpoint():
    def __init__(self, args ):
        print( "\n#================================ checkpoint 开始准备 =======================================\n")
        self.args = args
        self.ok = True
        self.n_processes = 8

        self.now = datetime.datetime.now().strftime('%Y-%m-%d-%H:%M:%S')

        # 模型训练时PSNR、MSE和loss和优化器等等数据的保存以及画图目录
        self.savedir = os.path.join(args.save_path, f"{self.now}_{args.modelUse}")
        os.makedirs(self.savedir, exist_ok = True)

        print(f"训练结果保存目录 = {self.savedir} ")

        # 模型参数保存的目录
        # self.modelSaveDir = os.path.join(args.ModelSave, f"{self.now}_Model_{args.modelUse}")
        self.modelSaveDir = self.args.ModelSave
        os.makedirs(self.modelSaveDir, exist_ok = True)

        # open_type = 'a' if os.path.exists(self.getSavePath('trainLog.txt')) else 'w'
        # self.log_file = open(self.getSavePath('trainLog.txt'), open_type)
        self.writeArgsLog(self.getSavePath('argsConfig.txt'))

        # Prepare test dir and so on:
        self.testResdir = os.path.join(self.savedir, "test_results")
        os.makedirs(self.testResdir, exist_ok=True)
        print(f"测试结果保存目录 = {self.testResdir} ")

        print( "\n#================================ checkpoint 准备完毕 =======================================\n")
        return

    def writeArgsLog(self, filename, open_type = 'w'):
        with open(filename, open_type) as f:
            f.write('====================================================================================\n')
            f.write(self.now + '\n')
            f.write('====================================================================================\n\n')

            f.write("###############################################################################\n")
            f.write("################################  args  #######################################\n")
            f.write("###############################################################################\n")

            for k, v in self.args.__dict__.items():
                f.write(f"{k: <25}: {str(v): <40}  {str(type(v)): <20}\n")
            f.write("\n################################ args end  ##################################\n")
        return


    def getSavePath(self, *subdir):
        return os.path.join(self.savedir, *subdir)

    # 写日志
    def write_log(self, log, train = False ):
        if train == True:
            logfile = self.getSavePath('trainLog.txt')
        else:
            logfile = self.get_testSavepath('testLog.txt')
        with open(logfile, 'a+') as f:
            f.write(log + '\n')
        return

    # 写日志
    def write_attacklog(self, log ):
        logfile = self.getSavePath('AttackLog.txt')
        with open(logfile, 'a+') as f:
            f.write(log + '\n')
        return

# >>> 测试相关函数
    # 初始化测试结果目录
    def get_testSavepath(self, *subdir):
        return os.path.join(self.testResdir, *subdir)


# <<< 测试相关函数





## 统计神经网络模型参数的均值和方差：
def  MeanVarStatistic(param_w):
    res = torch.Tensor()
    for key, val in param_w.items():
        res = torch.cat([res, val.clone().cpu().flatten()])
    var, mean = torch.var_mean(res)
    L1 = torch.linalg.vector_norm(res, ord = 1, )
    L2 = torch.linalg.vector_norm(res, ord = 2, )
    return  mean.item(), L1.item(), L2.item(), var.item()



# param_W =  torch.load("/home/jack/FedAvg_DataResults/results/param.pt")

# mean, L1, L2, var = MeanVarStatistic(param_W)
# print(f"mean = {mean}\nL1 = {L1}\nL2 = {L2}\nvar = {var}")

# mean = -0.0031799005810171366
# L1 = 25322.966796875
# L2 = 23.87314224243164
# var = 0.00033235494629479945

# res = torch.Tensor()
# for key, val in param_W.items():
#     res = torch.cat([res,val.clone().cpu().flatten()])
# L1 = torch.linalg.vector_norm(res, ord = 1, )
# var, mean = torch.var_mean(res)

















































































































































































