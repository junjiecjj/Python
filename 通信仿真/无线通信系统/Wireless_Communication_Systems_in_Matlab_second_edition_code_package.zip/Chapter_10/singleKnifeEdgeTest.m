h=20;f=10e9;d1=10e3;d2=5e3;%input parameters
[L_dB,n]=singleKnifeEdgeModel(h,f,d1,d2)%call singleKnifeEdgeModel