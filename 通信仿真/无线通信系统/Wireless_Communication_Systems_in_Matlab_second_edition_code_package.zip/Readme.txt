This code package is part of the following book (or ebook) 

Title: 'Wireless Communication Systems using Matlab'
Author: Mathuranathan Viswanathan

ISBN: 9798648350779 (color print)
ISBN: 9798648523210 (black & white print)

Installation
Add the location of the extracted contents to Matlab path.